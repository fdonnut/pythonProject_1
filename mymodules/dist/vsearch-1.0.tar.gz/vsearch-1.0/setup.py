from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='search tools',
    py_modules=['vsearch']
)
